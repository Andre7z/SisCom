package siscom.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.Hibernate;

import siscom.model.Compra;

public class CompraDAO {

    public boolean salvar(Compra compra) {
        Transaction transaction = null;

        try (Session session = Conexao.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.persist(compra);
            transaction.commit();
            return true;

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            return false;
        }
    }

    public boolean alterar(Compra compra) {
        Transaction transaction = null;

        try (Session session = Conexao.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.merge(compra);
            transaction.commit();
            return true;

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            return false;
        }
    }

    public boolean excluir(int id) {
        Transaction transaction = null;

        try (Session session = Conexao.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            Compra compra = session.get(Compra.class, id);

            if (compra == null) {
                transaction.rollback();
                return false;
            }

            session.remove(compra);
            transaction.commit();
            return true;

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            return false;
        }
    }

public List<Compra> pesquisar() {

    try (Session session = Conexao.getSessionFactory().openSession()) {

        List<Compra> lista =
                session.createQuery("from Compra", Compra.class).list();

        for (Compra compra : lista) {
            Hibernate.initialize(compra.getProdutos());
        }

        return lista;

    } catch (Exception e) {
        e.printStackTrace();
        return new ArrayList<>();
    }
}

public Compra pesquisarPorId(int id) {

    try (Session session = Conexao.getSessionFactory().openSession()) {

        Compra compra = session.get(Compra.class, id);

        if (compra != null) {
            Hibernate.initialize(compra.getProdutos());
        }

        return compra;

    } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
}
}
// public boolean salvar(Compra compra) {
//     try {
//         conn = Conexao.getConnection();

//         // salva compra
//         String sqlCompra = "INSERT INTO compra (data_compra, valor_total, fornecedor_id) VALUES (?, ?, ?)";
//         PreparedStatement psCompra = conn.prepareStatement(sqlCompra, PreparedStatement.RETURN_GENERATED_KEYS);

//         psCompra.setDate(1, java.sql.Date.valueOf(compra.getData_compra()));
//         psCompra.setDouble(2, compra.getValor_total());
//         psCompra.setInt(3, compra.getFornecedor().getId());

//         int qtdeLinhas = psCompra.executeUpdate();

//         // pega ID gerado
//         ResultSet rs = psCompra.getGeneratedKeys();
//         int idCompra = 0;

//         if (rs.next()) {
//             idCompra = rs.getInt(1);
//         }

//         rs.close();
//         psCompra.close();

//         // CompraProduto
//         for (CompraProduto cp : compra.getProdutos()) {

//             String sqlItem = "INSERT INTO compra_produto (compra_id, produto_id, quantidade, preco_unit) VALUES (?, ?, ?, ?)";
//             PreparedStatement psItem = conn.prepareStatement(sqlItem);

//             psItem.setInt(1, idCompra);
//             psItem.setInt(2, cp.getProduto().getId());
//             psItem.setInt(3, cp.getQuantidade());
//             psItem.setDouble(4, cp.getPreco_unit());

//             psItem.executeUpdate();
//             psItem.close();
//         }

//         return qtdeLinhas > 0;

//     } catch (Exception e) {
//         e.printStackTrace();
//         return false;
//     } finally {
//         Conexao.fecharConexao();
//     }
// }

//     public boolean excluir(int id) {
//         try {
//             conn = Conexao.getConnection();

//             String sql = "DELETE FROM compra WHERE id = ?";
//             PreparedStatement ps = conn.prepareStatement(sql);

//             ps.setInt(1, id);

//             int qtdeLinhas = ps.executeUpdate();
//             ps.close();

//             return qtdeLinhas > 0;

//         } catch (Exception e) {
//             e.printStackTrace();
//             return false;
//         } finally {
//             Conexao.fecharConexao();
//         }
//     }

//     public boolean alterar(Compra compra) {
//         try {
//             conn = Conexao.getConnection();

//             String sql = "UPDATE compra SET data_compra = ?, valor_total = ?, fornecedor_id = ? WHERE id = ?";
//             PreparedStatement ps = conn.prepareStatement(sql);

//             ps.setDate(1, java.sql.Date.valueOf(compra.getData_compra()));
//             ps.setDouble(2, compra.getValor_total());
//             ps.setInt(3, compra.getFornecedor().getId());
//             ps.setInt(4, compra.getId());

//             int qtdeLinhas = ps.executeUpdate();
//             ps.close();

//             return qtdeLinhas > 0;

//         } catch (Exception e) {
//             e.printStackTrace();
//             return false;
//         } finally {
//             Conexao.fecharConexao();
//         }
//     }

//     public List<Compra> pesquisarTodos() {
//         try {
//             List<Compra> compras = new ArrayList<>();

//             conn = Conexao.getConnection();

//             String sql = "SELECT * FROM compra";
//             PreparedStatement ps = conn.prepareStatement(sql);

//             ResultSet rs = ps.executeQuery();

//             while (rs.next()) {
//                 Compra compra = new Compra();
//                 Fornecedor fornecedor = new Fornecedor();

//                 compra.setId(rs.getInt("id"));
//                 compra.setData_compra(rs.getDate("data_compra").toLocalDate());
//                 compra.setValor_total(rs.getDouble("valor_total"));

//                 fornecedor.setId(rs.getInt("fornecedor_id"));
//                 compra.setFornecedor(fornecedor);

//                 compras.add(compra);
//             }

//             rs.close();
//             ps.close();

//             return compras;

//         } catch (Exception e) {
//             e.printStackTrace();
//             return null;
//         } finally {
//             Conexao.fecharConexao();
//         }
//     }